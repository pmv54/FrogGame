"""
Subcontroller module for Froggit

This module contains the subcontroller to manage a single level in the Froggit game.
Instances of Level represent a single game, read from a JSON.  Whenever you load a new
level, you are expected to make a new instance of this class.

The subcontroller Level manages the frog and all of the obstacles. However, those are
all defined in models.py.  The only thing in this class is the level class and all of
the individual lanes.

This module should not contain any more classes than Levels. If you need a new class,
it should either go in the lanes.py module or the models.py module.

# YOUR NAME AND NETID HERE
# DATE COMPLETED HERE
"""
from game2d import *
from consts import *
from lanes  import *
from models import *

# PRIMARY RULE: Level can only access attributes in models.py or lanes.py using getters
# and setters. Level is NOT allowed to access anything in app.py (Subcontrollers are not
# permitted to access anything in their parent. To see why, take CS 3152)


class Level(object):
    """
    This class controls a single level of Froggit.

    This subcontroller has a reference to the frog and the individual lanes.  However,
    it does not directly store any information about the contents of a lane (e.g. the
    cars, logs, or other items in each lane). That information is stored inside of the
    individual lane objects.

    If you want to pause the game, tell this controller to draw, but do not update.  See
    subcontrollers.py from Lesson 27 for an example.  This class will be similar to that
    one in many ways.

    All attributes of this class are to be hidden.  No attribute should be accessed
    without going through a getter/setter first.  However, just because you have an
    attribute does not mean that you have to have a getter for it.  For example, the
    Froggit app probably never needs to access the attribute for the Frog object, so
    there is no need for a getter.

    The one thing you DO need a getter for is the width and height.  The width and height
    of a level is different than the default width and height and the window needs to
    resize to match.  That resizing is done in the Froggit app, and so it needs to access
    these values in the level.  The height value should include one extra grid square
    to suppose the number of lives meter.
    """
    pass
    # LIST ALL HIDDEN ATTRIBUTES HERE
    # Attribute _lanes: contains a list of lanes that is in a level
    # Invariant: _lanes is a list containing GTile Objects
    #
    # Attribute _frog: contains the Frog Object
    # Invariant: _frog is a GImage object
    #
    # Attribute _lifelist: contains a list of frog heads
    # Invariant: _lifelist contains a series of GImage Objects
    #
    # Attribute _lives_label: A message that shows how many lives are left
    # Invariant: _lives_label is a GLabel
    #
    # Attribute _cooldown: states how many seconds there are before a frog can move
    # Invariant: _cooldown is a float

    # GETTERS AND SETTERS (ONLY ADD IF YOU NEED THEM)

    # INITIALIZER (standard form) TO CREATE THE FROG AND LANES
    def __init__(self, JSON, dt):
        sizeinfo = JSON['size']
        self.width = sizeinfo[0] * GRID_SIZE
        self.height = sizeinfo[1] * GRID_SIZE + GRID_SIZE

        laneslist = JSON['lanes']

        self._lanes = []
        for loopvariable in range(len(laneslist)):

            lanename = laneslist[loopvariable]['type']

            if lanename == 'grass':
                grass_object = Grass(JSON, loopvariable, lanename)
                self._lanes.append(grass_object)

            elif lanename == 'road':
                road_object = Road(JSON, loopvariable, lanename)
                self._lanes.append(road_object)

            elif lanename == 'water':
                water_object = Water(JSON, loopvariable, lanename)
                self._lanes.append(water_object)

            elif lanename == 'hedge':
                hedge_object = Hedge(JSON, loopvariable, lanename)
                self._lanes.append(hedge_object)

        coordinates = JSON['start']
        self._frog = Frog(coordinates[0],coordinates[1])
        self._frog.angle = FROG_NORTH

        life1 = GImage(x = self.width - GRID_SIZE / 2, y = self.height - GRID_SIZE / 2, width = GRID_SIZE, height = GRID_SIZE, source = FROG_HEAD)
        life2 = GImage(x = self.width - GRID_SIZE * 1.5, y = self.height - GRID_SIZE / 2 , width = GRID_SIZE, height = GRID_SIZE, right = life1.left, source = FROG_HEAD)
        life3 = GImage(x = self.width - GRID_SIZE * 2.5 , y = self.height - GRID_SIZE / 2, width = GRID_SIZE, height = GRID_SIZE, right = life2.left, source = FROG_HEAD)
        self._lifelist = [life1, life2, life3]
        self._lives_label = GLabel(text = 'LIVES:', font_size = ALLOY_SMALL, font_name = ALLOY_FONT, y = self.height - GRID_SIZE / 2, right = life3.left)

        self._cooldown = 0

    # UPDATE METHOD TO MOVE THE FROG AND UPDATE ALL OF THE LANES
    def update(self, input, dt):

        if self._cooldown <= 0:
            if input.is_key_down('right'):
                self._frog.angle = FROG_EAST
                if self._frog.x < (self.width - GRID_SIZE):
                    self._frog.x += GRID_SIZE
                    self._cooldown = FROG_SPEED

            elif input.is_key_down('left'):
                self._frog.angle = FROG_WEST
                if self._frog.x >= GRID_SIZE:
                    self._frog.x -= GRID_SIZE
                    self._cooldown = FROG_SPEED

            elif input.is_key_down('up'):
                self._frog.angle = FROG_NORTH
                if self._frog.y < (self.height - GRID_SIZE * 2):
                    self._frog.y += GRID_SIZE
                    self._cooldown = FROG_SPEED

            elif input.is_key_down('down'):
                self._frog.angle = FROG_SOUTH
                if self._frog.y > (GRID_SIZE):
                    self._frog.y -= GRID_SIZE
                    self._cooldown = FROG_SPEED

        self._cooldown -= dt

    # DRAW METHOD TO DRAW THE FROG AND THE INDIVIDUAL LANES
    def draw(self, view):
        for element in self._lanes:
            element.draw(view)

        if self._frog != None:
            self._frog.draw(view)

        for life in self._lifelist:
            life.draw(view)

        self._lives_label.draw(view)
    # ANY NECESSARY HELPERS (SHOULD BE HIDDEN)
